
class Negocio {
  final String nombre;
  final String categoria;
  final String descripcion;
  final double lat;
  final double lng;

  Negocio({
    required this.nombre,
    required this.categoria,
    required this.descripcion,
    required this.lat,
    required this.lng,
  });
}
